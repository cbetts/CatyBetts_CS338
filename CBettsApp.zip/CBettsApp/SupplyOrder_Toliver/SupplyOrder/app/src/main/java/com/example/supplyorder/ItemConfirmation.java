package com.example.supplyorder;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ItemConfirmation extends AppCompatActivity {
    private Patient patient;
    private ListView lv;
    private TextView tv;
    private ArrayAdapter icAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_confirmation);

        Intent intent = getIntent();
        patient = (Patient) intent.getSerializableExtra("pt_name_key");

        tv = (TextView) findViewById(R.id.ptNameTextView);
        tv.setText(patient.getName());

        lv = (ListView) findViewById(R.id.orderConfirmationList);
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        icAdapter = new ArrayAdapter<>(ItemConfirmation.this,
                android.R.layout.simple_list_item_multiple_choice, patient.listToString());

        lv.setAdapter(icAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it
        // is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_back:
                finish();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_show_list:
                //Arrays.toString(patient.getSupplyList().toArray());
                // have some kind of overlaid list show over screen
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void deleteItems(View view) {
        SparseBooleanArray checked = lv.getCheckedItemPositions();

        if (checked.size() == 0) {
            Context context = getApplicationContext();
            CharSequence msg = getString(R.string.del_error_toast);
            int duration = Toast.LENGTH_LONG;
            Toast.makeText(context, msg, duration).show();
        }
        else {
            for (int i = 0; i < checked.size(); i++) {
                SupplyItem item = new SupplyItem(lv.getAdapter().getItem(checked.keyAt(i)).toString());
                if (checked.valueAt(i) /*&& patient.getSupplyList().contains(item)*/ /*&& !patient.getSupplyList().isEmpty()*/) {
                    patient.removeItem(item);
                    System.out.println(item.getName() + " removed");
                }
            }
            //ocAdapter.notifyDataSetChanged(); doesn't seem to have any effect
            finish();
            startActivity(getIntent());
        }
    }

    public void addQuantities(View view) {
        Intent intent = new Intent(ItemConfirmation.this, QuantityConfirmation.class);
        intent.putExtra("pt_name_key", patient);
        startActivity(intent);
    }
}
