package com.example.supplyorder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Ryan on 8/30/2016.
 */
public class Patient implements Serializable {
    private String name;
    private ArrayList<SupplyItem> supplyList;

    public Patient(String name) {
        this.name = name;
        this.supplyList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public ArrayList<SupplyItem> getSupplyList() {
        return supplyList;
    }

    public void addItem(SupplyItem item) {
        if (findItem(item.getName()) < 0) {
            this.supplyList.add(item);
            System.out.println(item.getName() + " added");
        }
    }

    public int findItem(String item) {
        for (int i = 0; i < supplyList.size(); i++) {
            if (supplyList.get(i).getName().equals(item)) {
                System.out.println(item + " found");
                return i;
            }
        }
        return -1;
    }

    public void removeItem(SupplyItem item) {
        int position = findItem(item.getName());
        if (position > -1) {
            this.supplyList.remove(position);
            System.out.println(item.getName() + " removede");
        }
    }


    public String[] listToString() {
        String[] strList = new String[supplyList.size()];
        for (int i = 0; i < supplyList.size(); i++) {
            String itemName = this.getSupplyList().get(i).getName();
            strList[i] = itemName;
        }
        return strList;
    }
}
