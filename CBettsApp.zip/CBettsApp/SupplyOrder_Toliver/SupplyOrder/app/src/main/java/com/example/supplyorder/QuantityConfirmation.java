package com.example.supplyorder;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.TextView;

public class QuantityConfirmation extends AppCompatActivity implements NumberPicker.OnValueChangeListener {
    private Patient patient;
    private ListView lv;
    private TextView tv;
    private ArrayAdapter qcAdapter;
    //private Dialog d;
    //private NumberPicker np;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quantity_confirmation);

        Intent intent = getIntent();
        patient = (Patient) intent.getSerializableExtra("pt_name_key");

        tv = (TextView) findViewById(R.id.ptNameTextView);
        tv.setText(patient.getName());

        lv = (ListView) findViewById(R.id.quantConfirmationList);

        qcAdapter = new SupplyAdapter(QuantityConfirmation.this, patient.getSupplyList());

        lv.setAdapter(qcAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //SupplyItem itemPicked = (SupplyItem) adapterView.getItemAtPosition(i);
                showDialog();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it
        // is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_back:
                finish();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_show_list:
                //Arrays.toString(patient.getSupplyList().toArray());
                // have some kind of overlaid list show over screen
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onValueChange(NumberPicker numberPicker, int i, int i1) {
        Log.i("value is","" + i1);
    }

    /*public void showDialog() {
        final Dialog d = new Dialog(QuantityConfirmation.this);
        d.setTitle(R.string.change_quantity_dialog);
        d.setContentView(R.layout.quantity_dialog_layout);
        Button negBtn = (Button) d.findViewById(R.id.dialogNegBtn);
        Button posBtn = (Button) d.findViewById(R.id.dialogPosBtn);
        final NumberPicker np = (NumberPicker) d.findViewById(R.id.quantityNumberPicker);
        np.setMaxValue(20);
        np.setMinValue(1);
        np.setWrapSelectorWheel(false);
        np.setOnValueChangedListener(this);
        negBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d.dismiss();
            }
        });

        posBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d.dismiss();

            }
        });
        d.show();

    }*/

    public void showDialog() {
        AlertDialog.Builder d = new AlertDialog.Builder(QuantityConfirmation.this);

        //d.setView(R.layout.quantity_dialog_layout);
        d.setTitle("Test Title");
        d.setMessage("Test Message");

        d.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
            }
        });

        d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
            }
        });

        AlertDialog dialog = d.create();
        dialog.show();


    }

    public void submitOrder(View view) {
        // similar to reviewOrder in SupplyCategories
    }
}
