package com.example.supplyorder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by rtol on 9/21/16.
 */

public class SupplyAdapter extends ArrayAdapter<SupplyItem> {

    public SupplyAdapter(Context context, ArrayList<SupplyItem> supplyList) {
        super(context, R.layout.row_layout, supplyList);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater slInflater = LayoutInflater.from(getContext());
        View slView = slInflater.inflate(R.layout.row_layout, parent, false);

        String itemName = getItem(position).getName();
        TextView slTextViewPtName = (TextView) slView.findViewById(R.id.itemName);
        slTextViewPtName.setText(itemName);

        //String itemQuantity = String.valueOf(getItem(position).getAmount());
        int itemQuantity = getItem(position).getAmount();
        TextView slTextViewItemQuantity = (TextView) slView.findViewById(R.id.itemQuantity);
        slTextViewItemQuantity.setText(String.format("%1$s %2$d", "Quantity: ", itemQuantity));

        return slView;
    }
}
