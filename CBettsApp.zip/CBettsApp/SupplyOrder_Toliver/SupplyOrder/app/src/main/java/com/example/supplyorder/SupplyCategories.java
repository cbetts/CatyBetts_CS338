package com.example.supplyorder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class SupplyCategories extends AppCompatActivity {
    private Patient patient;
    private ListView lv;
    private TextView tv;
    private ArrayAdapter mainCategoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supply_categories);

        Intent intent = getIntent();
        patient = (Patient) intent.getSerializableExtra("pt_name_key");
        tv = (TextView) findViewById(R.id.ptNameTextView);
        tv.setText(patient.getName());

        String[] mainCategoryList = getResources().getStringArray(R.array.main_categories);

        mainCategoryAdapter = new ArrayAdapter<>(this, android.R.layout.
                simple_list_item_activated_1, mainCategoryList);
        lv = (ListView) findViewById(R.id.mainCategories);
        lv.setAdapter(mainCategoryAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String categoryPicked = String.valueOf(adapterView.getItemAtPosition(i));

                setContentView(R.layout.subcategories_layout);
                tv = (TextView) findViewById(R.id.ptNameTextView);
                tv.setText(patient.getName());

                lv = (ListView) findViewById(R.id.subcategoryList);
                lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

                switch (categoryPicked) {
                    case "Feeding":
                        String[] feedingSupplyList = getResources().getStringArray(R.array.
                                feeding_supplies);
                        ArrayAdapter fsAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, feedingSupplyList);
                        lv.setAdapter(fsAdapter);
                        break;
                    case "Medication":
                        String[] medSupplyList = getResources().getStringArray(R.array.
                                med_supplies);
                        ArrayAdapter msAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, medSupplyList);
                        lv.setAdapter(msAdapter);
                        break;
                    case "Personal Care":
                        String[] pcSupplyList = getResources().getStringArray(R.array.
                                personal_care_supplies);
                        ArrayAdapter pcAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, pcSupplyList);
                        lv.setAdapter(pcAdapter);
                        break;
                    case "Gloves / Wipes / Pads / Pull-ups / Briefs":
                        String[] gwppbSupplyList = getResources().getStringArray(R.array.
                                gwppb_supplies);
                        ArrayAdapter gwppbAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, gwppbSupplyList);
                        lv.setAdapter(gwppbAdapter);
                        break;
                    case "Incontinence":
                        String[] isSupplyList = getResources().getStringArray(R.array.
                                incontinence_supplies);
                        ArrayAdapter isAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, isSupplyList);
                        lv.setAdapter(isAdapter);
                        break;
                    case "Wound Care":
                        String[] wcSupplyList = getResources().getStringArray(R.array.
                                woundcare_supplies);
                        ArrayAdapter wcAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, wcSupplyList);
                        lv.setAdapter(wcAdapter);
                        break;
                    case "General Care":
                        String[] gcSupplyList = getResources().getStringArray(R.array.
                                gencare_supplies);
                        ArrayAdapter gcAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, gcSupplyList);
                        lv.setAdapter(gcAdapter);
                        break;
                    case "Respiratory / Suction Care":
                        String[] rcSupplyList = getResources().getStringArray(R.array.
                                resp_supplies);
                        ArrayAdapter rcAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, rcSupplyList);
                        lv.setAdapter(rcAdapter);
                        break;
                    case "Bag Stock":
                        String[] bsSupplyList = getResources().getStringArray(R.array.
                                bagstock_supplies);
                        ArrayAdapter bsAdapter = new ArrayAdapter<>(SupplyCategories.this,
                                android.R.layout.simple_list_item_multiple_choice, bsSupplyList);
                        lv.setAdapter(bsAdapter);

                        break;
                }
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it
        // is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_back:
                finish();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_show_list:
                //Arrays.toString(patient.getSupplyList().toArray());
                // have some kind of overlaid list show over screen
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void addItems(View view) {
        SparseBooleanArray checked = lv.getCheckedItemPositions();

        for (int i = 0; i < checked.size(); i++) {
            SupplyItem item = new SupplyItem(lv.getAdapter().getItem(checked.keyAt(i)).toString());
            if (checked.valueAt(i) && !patient.getSupplyList().contains(item)) {
                patient.addItem(item);
            }
            else {
                if (patient.getSupplyList().contains(item)) {
                    patient.getSupplyList().remove(item);
                }
            }

        }

        Intent intent = new Intent(SupplyCategories.this, SupplyCategories.class);
        intent.putExtra("pt_name_key", patient);
        startActivity(intent);
    }

    public void reviewOrder(View view) {
        SparseBooleanArray checked = lv.getCheckedItemPositions();

        for (int i = 0; i < checked.size(); i++) {
            SupplyItem item = new SupplyItem(lv.getAdapter().getItem(checked.keyAt(i)).toString());
            if (checked.valueAt(i) && !patient.getSupplyList().contains(item)) {
                patient.addItem(item);
                System.out.println(item.getName() + " added");
            }
            else {
                if (patient.getSupplyList().contains(item)) {
                    patient.getSupplyList().remove(item);
                }
            }

        }

        Intent intent = new Intent(SupplyCategories.this, ItemConfirmation.class);
        intent.putExtra("pt_name_key", patient);
        startActivity(intent);
    }

    /*@Override
    public void onResume() {
        super.onResume();
        mainCategoryAdapter.notifyDataSetChanged();
    }*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        /*Intent intent = new Intent(SupplyCategories.this, SupplyCategories.class);
        intent.putExtra("pt_name_key", patient);
        startActivity(intent);*/
        finish();
        startActivity(getIntent());

    }
}
