package com.example.supplyorder;

import java.io.Serializable;

/**
 * Created by Ryan on 8/30/2016.
 */
public class SupplyItem implements Serializable {
    private String name;
    private int amount;

    public SupplyItem(String name) {
        this.name = name;
        this.amount = 1;
    }

    public String getName() {
        return name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
