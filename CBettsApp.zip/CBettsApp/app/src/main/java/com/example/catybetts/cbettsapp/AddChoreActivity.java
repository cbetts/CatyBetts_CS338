package com.example.catybetts.cbettsapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

/**AddChoreActivity - adds a chore to the database
 *
 */
public class AddChoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_chore);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_chore, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        //handles presses on the action bar items
        switch(item.getItemId()){
            case R.id.action_home:
                setContentView(R.layout.activity_main);
                startActivity(new Intent(this, MainActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**cancelAddChore - cancels the adding of the chore and returns to home screen
     *
     * @param view
     */
    public void cancelAddChore(View view) {
        setContentView(R.layout.activity_main);
        startActivity(new Intent(this, MainActivity.class));
    }

    public void addChore(View view) {
        DatabaseManager dbMgr = new DatabaseManager (this);
        String name = ((TextView) findViewById(R.id.name)).getText().toString();
        String frequency = ((TextView) findViewById(R.id.frequency)).getText().toString();
        String lastDatePerformed = ((TextView) findViewById(R.id.lastDatePerformed)).getText().toString();
        String timeNeeded = ((TextView) findViewById(R.id.timeNeeded)).getText().toString();
        String nextDate = ((TextView) findViewById(R.id.nextDate)).getText().toString();

        Chore chore = new Chore(name, frequency, lastDatePerformed, timeNeeded, nextDate);
        dbMgr.addChore(chore);
        startActivity(new Intent(this, AddChoreActivity.class));
        finish();
    }
}