package com.example.catybetts.cbettsapp;

/**Chore.java - creates a Chore object
 *
 */

public class Chore {
    private long id;
    private String name;
    private String frequency;                      //how many times per week?
    private String lastDatePerformed;              //last date completed
    private String timeNeeded;                     //in quarter hour increments (.25 = 15 minutes)
    private String nextDate;

    /**Chore() - empty constructor
     *
     */
    public Chore(){
    }

    /**Chore() - constructor with parameters
     *
     * @param name
     * @param frequency
     * @param lastDatePerformed
     * @param timeNeeded
     * @param nextDate
     */
    public Chore(String name, String frequency,
                 String lastDatePerformed, String timeNeeded, String nextDate) {
        this.name = name;
        this.frequency = frequency;
        this.lastDatePerformed = lastDatePerformed;
        this.timeNeeded = timeNeeded;
        this.nextDate = nextDate;
    }

    public String getNextDate() {return nextDate;}

    public void setNextDate(String nextDate) {this.nextDate = nextDate;}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {this.frequency = frequency;}

    public String getLastDatePerformed() {return lastDatePerformed;}

    public void setLastDatePerformed(String lastDatePerformed) {this.lastDatePerformed = lastDatePerformed;}

    public String getTimeNeeded() {return timeNeeded;}

    public void setTimeNeeded(String timeNeeded) {this.timeNeeded = timeNeeded;}
}
