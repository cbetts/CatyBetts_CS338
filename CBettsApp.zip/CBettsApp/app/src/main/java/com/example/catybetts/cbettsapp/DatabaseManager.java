package com.example.catybetts.cbettsapp;

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**Database Manager - methods to manage the database
 *
 */
public class DatabaseManager extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "chores";
    public static final String ID_FIELD = "_id";
    public static final String NAME_FIELD = "chore_name";
    public static final String FREQUENCY_FIELD = "frequency";
    public static final String LAST_DATE_PERFORMED_FIELD = "last_date_performed";
    public static final String TIME_NEEDED_FIELD = "time_needed";
    public static final String NEXT_DATE_FIELD = "next_date";
    public DatabaseManager(Context context) {
        super(context,
                /*db name=*/ "chores_db2",
                /*cursorFactory=*/ null,
                /*db version=*/1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("db", "onCreate");
        String sql = "CREATE TABLE " + TABLE_NAME
                + " (" + ID_FIELD + " INTEGER, "
                + NAME_FIELD + " TEXT, "
                + FREQUENCY_FIELD + " TEXT,"
                + LAST_DATE_PERFORMED_FIELD + " TEXT,"
                + TIME_NEEDED_FIELD + " TEXT,"
                + NEXT_DATE_FIELD + " TEXT,"
                + " PRIMARY KEY (" + ID_FIELD + "));";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
        Log.d("db", "onUpdate");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // re-create the table
        onCreate(db);
    }

    public Chore addChore(Chore chore) {
        Log.d("db", "addChore");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FREQUENCY_FIELD, chore.getFrequency());
        values.put(LAST_DATE_PERFORMED_FIELD, chore.getLastDatePerformed());
        values.put(TIME_NEEDED_FIELD, chore.getTimeNeeded());
        values.put(NAME_FIELD, chore.getName());
        values.put(NEXT_DATE_FIELD, chore.getNextDate());
        long id = db.insert(TABLE_NAME, null, values);
        chore.setId(id);
        db.close();
        return chore;
    }

    // Getting single contact
    Chore getChore(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[] {
                        ID_FIELD, NAME_FIELD,FREQUENCY_FIELD,
                        LAST_DATE_PERFORMED_FIELD, TIME_NEEDED_FIELD, NEXT_DATE_FIELD }, ID_FIELD + "=?",
                new String[] { String.valueOf(id) }, null,
                null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            Chore chore = new Chore(
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5));
            chore.setId(cursor.getLong(0));
            return chore;
        }
        return null;
    }

    // Getting All Contacts
    public List<Chore> getAllChores() {
        List<Chore> chores = new ArrayList<Chore>();
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {
            Chore chore = new Chore();
            chore.setId(Integer.parseInt(cursor.getString(0)));
            chore.setName(cursor.getString(1));
            chore.setFrequency(cursor.getString(2));
            chore.setLastDatePerformed(cursor.getString(3));
            chore.setTimeNeeded(cursor.getString(4));
            chore.setNextDate(cursor.getString(5));
            chores.add(chore);
        }
        return chores;
    }

    public Cursor getChoresCursor() {
        String selectQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery(selectQuery, null);
    }

    public int updateChore(Chore chore) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FREQUENCY_FIELD, chore.getFrequency());
        values.put(LAST_DATE_PERFORMED_FIELD, chore.getLastDatePerformed());
        values.put(TIME_NEEDED_FIELD, chore.getTimeNeeded());
        values.put(NAME_FIELD, chore.getName());
        values.put(NEXT_DATE_FIELD, chore.getNextDate());
        return db.update(TABLE_NAME, values, ID_FIELD + " = ?",
                new String[] { String.valueOf(chore.getId()) });
    }

    public void deleteChore(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, ID_FIELD + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }
}