package com.example.catybetts.cbettsapp;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class EditChoreActivity extends AppCompatActivity{

    long choreId;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_chore);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            choreId = extras.getLong("id");
            DatabaseManager dbMgr = new DatabaseManager(this);
            Chore chore = dbMgr.getChore(choreId);
            if (chore != null) {
                ((TextView) findViewById(R.id.name)).setText(chore.getName());
                ((TextView) findViewById(R.id.frequency)).setText(chore.getFrequency());
                ((TextView) findViewById(R.id.lastDatePerformed)).setText(chore.getLastDatePerformed());
                ((TextView) findViewById(R.id.timeNeeded)).setText(chore.getTimeNeeded());
                ((TextView) findViewById(R.id.nextDate)).setText(chore.getNextDate());
            } else {
                Log.d("dbMyApp5", "contact null");
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_home:
                setContentView(R.layout.activity_main);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void saveChore(View view) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            choreId = extras.getLong("id");
            DatabaseManager dbMgr = new DatabaseManager(this);
            Chore chore = dbMgr.getChore(choreId);
            if (chore != null) {
                ((TextView) findViewById(R.id.name)).setText(chore.getName());
                ((TextView) findViewById(R.id.frequency)).setText(chore.getFrequency());
                ((TextView) findViewById(R.id.lastDatePerformed)).setText(chore.getLastDatePerformed());
                ((TextView) findViewById(R.id.timeNeeded)).setText(chore.getTimeNeeded());
                ((TextView) findViewById(R.id.nextDate)).setText(chore.getNextDate());
            } else {
                Log.d("dbMyApp5", "contact null");
            }
            setContentView(R.layout.activity_show_chore);
        }
    }
    public void cancelEditChore(View view) {
        setContentView(R.layout.activity_view_chores);
        startActivity(new Intent(this, ViewChoresActivity.class));
    }
}
