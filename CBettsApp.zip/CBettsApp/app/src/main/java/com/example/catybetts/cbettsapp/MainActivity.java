package com.example.catybetts.cbettsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.database.Cursor;
import android.widget.CursorAdapter;
import android.view.MenuItem;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        //handles presses on the action bar items
        switch(item.getItemId()){
            case R.id.action_add_chore:
                startActivity(new Intent(this, AddChoreActivity.class));
                setContentView(R.layout.activity_add_chore);
                return true;
            case R.id.action_home:
                setContentView(R.layout.activity_main);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void openAddChore(View view){
        startActivity(new Intent(this, AddChoreActivity.class));
        setContentView(R.layout.activity_add_chore);
    }

    public void openViewChores(View view){
        startActivity(new Intent(this, ViewChoresActivity.class));
        setContentView(R.layout.activity_view_chores);
    }

    public void openPrintSchedule(View view){
        startActivity(new Intent(this, PrintScheduleActivity.class));
        setContentView(R.layout.activity_print_schedule);
    }
}
