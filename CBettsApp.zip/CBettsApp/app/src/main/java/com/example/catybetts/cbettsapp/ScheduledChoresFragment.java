package com.example.catybetts.cbettsapp;

import android.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import static com.example.catybetts.cbettsapp.R.id.listView;

/**
 * Created by Caty on 10/13/2016.
 */

public class ScheduledChoresFragment extends Fragment{
    DatabaseManager dbMgr;
    ListAdapter adapter;
    ListView listView;
    Cursor cursor;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_scheduled, container, false);

        listView = (ListView) view.findViewById(com.example.catybetts.cbettsapp.R.id.scheduledListView);
        dbMgr = new DatabaseManager(getActivity());

        cursor = dbMgr.getChoresCursor();

        adapter = new SimpleCursorAdapter(getActivity(),
                android.R.layout.two_line_list_item,
                cursor,
                new String[] {DatabaseManager.NAME_FIELD,
                        DatabaseManager.NEXT_DATE_FIELD},
                new int[] {android.R.id.text1, android.R.id.text2},
                CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView,
                                            View view, int position, long id) {
                        Intent intent = new Intent(getActivity(),ShowChoreActivity.class);
                        intent.putExtra("id", id);
                        startActivity(intent);
                    }
                });
        return view;
    }

}
