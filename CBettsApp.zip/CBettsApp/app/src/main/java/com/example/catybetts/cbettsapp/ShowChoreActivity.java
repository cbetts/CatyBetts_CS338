package com.example.catybetts.cbettsapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.view.View;


public class ShowChoreActivity extends Activity {
    long choreId;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_chore);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            choreId = extras.getLong("id");
            DatabaseManager dbMgr = new DatabaseManager(this);
            Chore chore = dbMgr.getChore(choreId);
            if (chore != null) {
                ((TextView) findViewById(R.id.name)).setText(chore.getName());
                ((TextView) findViewById(R.id.frequency)).setText(chore.getFrequency());
                ((TextView) findViewById(R.id.lastDatePerformed)).setText(chore.getLastDatePerformed());
                ((TextView) findViewById(R.id.timeNeeded)).setText(chore.getTimeNeeded());
                ((TextView) findViewById(R.id.nextDate)).setText(chore.getNextDate());

            } else {
                Log.d("dbMyApp5", "contact null");
            }

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_show_chore, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_home:
                setContentView(R.layout.activity_main);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void deleteChore(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Please confirm")
                .setMessage(
                        "Are you sure you want to delete " +
                                "this contact?")
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog,
                                    int whichButton) {
                                DatabaseManager dbMgr =
                                        new DatabaseManager(
                                                getApplicationContext());
                                dbMgr.deleteChore(choreId);
                                dialog.dismiss();
                                finish();
                            }
                        })
                .setNegativeButton("No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog,
                                    int which) {
                                dialog.dismiss();
                            }
                        })
                .create()
                .show();
    }

    public void editChore(View view){
        startActivity(new Intent(this, EditChoreActivity.class));
        setContentView(R.layout.activity_edit_chore);
    }
}