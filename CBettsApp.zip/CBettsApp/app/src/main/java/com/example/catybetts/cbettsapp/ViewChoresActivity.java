package com.example.catybetts.cbettsapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**ViewChoresActivity - shows a list of all chores in the database
 *
 */
public class ViewChoresActivity extends AppCompatActivity {
    DatabaseManager dbMgr;
    ListAdapter adapter;
    ListView listView;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_chores);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        //handles presses on the action bar items
        switch(item.getItemId()){
            case R.id.action_home:
                setContentView(R.layout.activity_main);
                startActivity(new Intent(this, MainActivity.class));
                return true;
            case R.id.action_add_chore:
                startActivity(new Intent(this, AddChoreActivity.class));
                setContentView(R.layout.activity_add_chore);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}